The template (example) provided is for the MSWord camera-ready format to SCITEPRESS Doctoral Consortium.


